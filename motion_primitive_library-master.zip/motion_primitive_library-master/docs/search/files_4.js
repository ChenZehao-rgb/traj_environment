var searchData=
[
  ['lambda_2eh',['lambda.h',['../lambda_8h.html',1,'']]]
];
