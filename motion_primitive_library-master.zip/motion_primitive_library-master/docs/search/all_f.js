var searchData=
[
  ['quad',['quad',['../math_8h.html#a5b1ef571b298b14e320d7d9f31528871',1,'math.h']]],
  ['quartic',['quartic',['../math_8h.html#a11e53038927f416e637df83d4a0b18bc',1,'math.h']]]
];
