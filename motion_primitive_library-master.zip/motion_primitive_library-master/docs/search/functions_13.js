var searchData=
[
  ['waypoint',['Waypoint',['../structWaypoint.html#aa40502a0517dbb938dc35a52acc89feb',1,'Waypoint::Waypoint()'],['../structWaypoint.html#a6d7eaadca98b8aa854e5953c8f983de7',1,'Waypoint::Waypoint(Control::Control c)']]]
];
