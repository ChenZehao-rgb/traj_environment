var searchData=
[
  ['snp',['SNP',['../control_8h.html#af3600af994b25be7c568791eefdadf2ead0c08f6b92d9b7cfe392322c75e4620c',1,'Control']]],
  ['snpxyaw',['SNPxYAW',['../control_8h.html#af3600af994b25be7c568791eefdadf2eab55a3e8019f3292b6cfbb28c687e7975',1,'Control']]]
];
