var searchData=
[
  ['n_5f',['N_',['../classPolySolver.html#a05e80fc467c2fd6ed86b2406b46cee8b',1,'PolySolver']]]
];
