# ---
#
# Nothing to see here, as the Python version *always* uses a dynamic number of degrees of freedom.
#
# ---
